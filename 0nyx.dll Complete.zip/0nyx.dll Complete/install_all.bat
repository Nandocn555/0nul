@echo off
chcp 65001 >nul
mode con: cols=120 lines=45
title 0NUL_INSTALLER :: ROOT_ACCESS :: INITIALIZING...

:: ============================================
:: CONFIG :: SYSTEM PATHS
:: ============================================
set "PIP_PATH=C:\Users\Nandocn.555\AppData\Local\Programs\Python\Python312\Scripts\pip.exe"
set "PY_PATH=C:\Users\Nandocn.555\AppData\Local\Programs\Python\Python312\python.exe"

:: ============================================
:: INITIAL TERMINAL BOOT SEQUENCE
:: ============================================
cls
color 0A
echo.
echo.
echo        ╔═══════════════════════════════════════════════════════════════════════════════╗
echo        ║                                                                               ║
echo        ║  ███████╗ ██████╗███╗   ██╗██╗   ██╗██╗      ██████╗ ███████╗██████╗         ║
echo        ║  ██╔════╝██╔════╝████╗  ██║██║   ██║██║     ██╔═══██╗██╔════╝██╔══██╗        ║
echo        ║  █████╗  ██║     ██╔██╗ ██║██║   ██║██║     ██║   ██║█████╗  ██████╔╝        ║
echo        ║  ██╔══╝  ██║     ██║╚██╗██║██║   ██║██║     ██║   ██║██╔══╝  ██╔══██╗        ║
echo        ║  ██║     ╚██████╗██║ ╚████║╚██████╔╝███████╗╚██████╔╝███████╗██║  ██║        ║
echo        ║  ╚═╝      ╚═════╝╚═╝  ╚═══╝ ╚═════╝ ╚══════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝        ║
echo        ║                                                                               ║
echo        ║                    0NUL SYSTEM :: DEPLOYMENT PROTOCOL 3.1.4                   ║
echo        ║                                                                               ║
echo        ╚═══════════════════════════════════════════════════════════════════════════════╝
echo.
echo                    [SYSTEM] Initializing installation matrix...
echo                    [STATUS] Connecting to Python repository...
timeout /t 2 /nobreak >nul
echo.

:: ============================================
:: PHASE 1 :: PIP ENHANCEMENT
:: ============================================
echo        [PHASE 1/7] :: PIP_UPGRADE :: INITIATING...
echo        ═══════════════════════════════════════════════════════════════════════════════════════════
"%PIP_PATH%" install --upgrade pip --quiet >nul 2>&1
echo        [✓] Pip upgrade completed
echo        [✓] Repository access: GRANTED
echo.

:: ============================================
:: PHASE 2 :: CORE MODULES
:: ============================================
echo        [PHASE 2/7] :: CORE_MODULES :: DEPLOYING...
echo        ═══════════════════════════════════════════════════════════════════════════════════════════
set CORE=requests colorama rich typer click pyfiglet termcolor
echo        [»] Installing: %CORE%
"%PIP_PATH%" install %CORE% --quiet >nul 2>&1
echo        [✓] Core modules: ACTIVE
echo        [»] System stability: 100%%
echo.

:: ============================================
:: PHASE 3 :: NETWORK TOOLKIT
:: ============================================
echo        [PHASE 3/7] :: NETWORK_PROTOCOLS :: LOADING...
echo        ═══════════════════════════════════════════════════════════════════════════════════════════
set NETWORK=scapy paramiko pysocks socks httpx aiohttp dnspython whois geoip2 phonenumbers
echo        [»] Deploying network modules...
"%PIP_PATH%" install %NETWORK% --quiet >nul 2>&1
echo        [✓] Network stack: ONLINE
echo        [»] Packet injection: READY
echo.

:: ============================================
:: PHASE 4 :: WEB EXPLOITATION
:: ============================================
echo        [PHASE 4/7] :: WEB_SCRAPING :: INITIALIZING...
echo        ═══════════════════════════════════════════════════════════════════════════════════════════
set WEB=beautifulsoup4 lxml selenium playwright scrapy mechanize
echo        [»] Loading web exploitation tools...
"%PIP_PATH%" install %WEB% --quiet >nul 2>&1
echo        [✓] Web modules: DEPLOYED
echo        [»] DOM manipulation: ENABLED
echo.

:: ============================================
:: PHASE 5 :: CRYPTO & SECURITY
:: ============================================
echo        [PHASE 5/7] :: CRYPTO_SUITE :: DECRYPTING...
echo        ═══════════════════════════════════════════════════════════════════════════════════════════
set CRYPTO=cryptography pycryptodome hashlib passlib bcrypt
echo        [»] Installing encryption protocols...
"%PIP_PATH%" install %CRYPTO% --quiet >nul 2>&1
echo        [✓] Crypto modules: SECURED
echo        [»] AES-256 encryption: ACTIVE
echo.

:: ============================================
:: PHASE 6 :: SYSTEM AUTOMATION
:: ============================================
echo        [PHASE 6/7] :: AUTOMATION_DRIVERS :: STARTING...
echo        ═══════════════════════════════════════════════════════════════════════════════════════════
set AUTO=pyautogui keyboard mouse psutil pywin32 schedule watchdog
echo        [»] Deploying automation toolkit...
"%PIP_PATH%" install %AUTO% --quiet >nul 2>&1
echo        [✓] Automation: ARMED
echo        [»] System control: FULL ACCESS
echo.

:: ============================================
:: PHASE 7 :: ADVANCED TOOLS
:: ============================================
echo        [PHASE 7/7] :: ADVANCED_MODULES :: FINALIZING...
echo        ═══════════════════════════════════════════════════════════════════════════════════════════
set ADVANCED=pandas numpy opencv-python pillow flask discord.py
echo        [»] Installing advanced weaponry...
"%PIP_PATH%" install %ADVANCED% --quiet >nul 2>&1
echo        [✓] Advanced modules: LOADED
echo        [»] Data processing: OPERATIONAL
echo.

:: ============================================
:: VERIFICATION SEQUENCE
:: ============================================
echo        [SYSTEM] Running verification protocol...
echo        ═══════════════════════════════════════════════════════════════════════════════════════════
timeout /t 1 /nobreak >nul
echo        [»] Testing module imports...
"%PY_PATH%" -c "import requests, colorama, scapy, cryptography, selenium" >nul 2>&1
if %errorlevel% equ 0 (
    echo        [✓] All critical modules: VERIFIED
) else (
    echo        [!] Some modules failed verification
)
echo.

:: ============================================
:: LAUNCH SEQUENCE
:: ============================================
echo        [SYSTEM] Preparing to launch 0NUL...
echo        ═══════════════════════════════════════════════════════════════════════════════════════════
echo        [»] Starting terminal session...
echo        [»] Loading interface...
echo        [»] Establishing connection...
timeout /t 3 /nobreak >nul

cls
color 0A
echo.
echo.
echo        ╔═══════════════════════════════════════════════════════════════════════════════╗
echo        ║                                                                               ║
echo        ║  ███████╗███╗   ██╗██████╗ ██╗   ██╗██╗      ██████╗ ███████╗██████╗         ║
echo        ║  ██╔════╝████╗  ██║██╔══██╗██║   ██║██║     ██╔═══██╗██╔════╝██╔══██╗        ║
echo        ║  █████╗  ██╔██╗ ██║██████╔╝██║   ██║██║     ██║   ██║█████╗  ██████╔╝        ║
echo        ║  ██╔══╝  ██║╚██╗██║██╔══██╗██║   ██║██║     ██║   ██║██╔══╝  ██╔══██╗        ║
echo        ║  ██║     ██║ ╚████║██║  ██║╚██████╔╝███████╗╚██████╔╝███████╗██║  ██║        ║
echo        ║  ╚═╝     ╚═╝  ╚═══╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝        ║
echo        ║                                                                               ║
echo        ║                         INSTALLATION COMPLETE :: SYSTEM READY                  ║
echo        ║                                                                               ║
echo        ╠═══════════════════════════════════════════════════════════════════════════════╣
echo        ║                                                                               ║
echo        ║  [STATUS]  All dependencies: DEPLOYED                                         ║
echo        ║  [MODULES] 35+ packages installed                                             ║
echo        ║  [ACCESS]  Root privileges: GRANTED                                           ║
echo        ║  [NETWORK] Localhost: SECURED                                                 ║
echo        ║                                                                               ║
echo        ║  [»] Press any key to launch 0NUL system...                                   ║
echo        ║                                                                               ║
echo        ╚═══════════════════════════════════════════════════════════════════════════════╝

pause >nul

:: ============================================
:: LAUNCH 0NUL
:: ============================================
cls
color 0A
echo.
echo        [SYSTEM] Launching 0NUL v3.1.4...
echo        [»] Loading mainframe...
echo        [»] Establishing secure connection...
echo        [»] Bypassing security protocols...
timeout /t 2 /nobreak >nul

cd /d "C:\Users\Nandocn.555\Desktop\Cyb3rtech-Tool-main"
"%PY_PATH%" 0nul.py

echo.
echo        [SYSTEM] Process terminated with code %errorlevel%
echo        [»] Session encrypted and logged
echo        [»] Returning to shadow mode...
timeout /t 3 /nobreak >nul
exit