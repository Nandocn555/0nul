@echo off
echo Ejecutando Cyb3rtech Tool...
echo.
python "0nul.py"
echo.
echo Codigo de salida: %errorlevel%
pause